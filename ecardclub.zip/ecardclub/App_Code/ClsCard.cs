﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for ClsCard
/// </summary>
public class ClsCard
{
    public SqlConnection con = new SqlConnection();
    public SqlCommand cmd;
    public SqlDataReader dr;
    public SqlDataAdapter da;
    public DataSet ds = new DataSet();
    public string Query;
    public int Sid;
    public void connect()
    {
        con.ConnectionString = ConfigurationManager.ConnectionStrings["Csclub"].ConnectionString;
        con.Open();
    }
    public void SelectData(String Query)
    {
        cmd = new SqlCommand(Query, con);
        dr = cmd.ExecuteReader();
    }
    public void WriteData(String Query)
    {
        cmd = new SqlCommand(Query, con);
        cmd.ExecuteNonQuery();
    }
    public void GetDataSet(string Query)
    {
        cmd = new SqlCommand(Query, con);
        da = new SqlDataAdapter(cmd);
        da.Fill(ds);
    }
	public ClsCard()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}