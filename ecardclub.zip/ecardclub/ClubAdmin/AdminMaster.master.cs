﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_AdminMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/AdminHome.aspx");
    }

    protected void lbtnFormat_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Frmt.aspx");
    }

    protected void lbtnStyle_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Styl.aspx");
    }

    protected void lbtnColor_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Colr.aspx");
    }

    protected void lbtnSize_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Size.aspx");
    }

    protected void lbtnPaperType_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Papr_typ.aspx");
    }

    protected void lbtnPrinting_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Prntng_tech.aspx");
    }

    protected void lbtnCardSuite_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Card_suit.aspx");
    }

    protected void lbtnEnvelop_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Envlp_trm_optns.aspx");
    }

    protected void lbtnSignature_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Signtr_colctn.aspx");
    }

    protected void lbtnEvent_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/ManageEv_type.aspx");
    }

    protected void lbtnProvide_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Provide_Crd_smpl.aspx");
    }

    protected void lbtnState_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_State.aspx");
    }

    protected void lbtnDist_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Distrct.aspx");
    }

    protected void lbtnPaymentType_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Paymnt_typ.aspx");
    }

    protected void lbtnShipment_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Shpmnt_mod.aspx");
    }

    protected void lbtnActiveCust_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/ViewndActivate_custmr.aspx");
    }

    protected void lbtnActiveCard_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Activate_Crd_rqst.aspx");
    }

    protected void lbtnViewPayment_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/View_Paymnt.aspx");
    }

    protected void lbtnCardClub_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Crdclb_brnch.aspx");
    }

    protected void lbtnLogOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Clear();
        Session["agencyid"] = null;
        Session["agencyname"] = null;
        Session["ag_hold_name"] = null;
        Response.Redirect("~/Registration/login.aspx");
    }
}
