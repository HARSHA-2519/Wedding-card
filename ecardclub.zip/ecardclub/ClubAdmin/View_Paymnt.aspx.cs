﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_View_Paymnt : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindpymnt();
        }
    }
    //bind payment into gridview control
    protected void bindpymnt()
    {
        obj.Query = "SELECT Payment.*, Payment_type.Pay_type, Customer_request.Reqid AS Expr1 FROM Payment INNER JOIN Payment_type ON Payment.Pay_typeid = Payment_type.Pay_typeid INNER JOIN Customer_request ON Payment.Reqid = Customer_request.Reqid";
        obj.SelectData(obj.Query);
        grdviewpaymnt.DataSource = obj.dr;
        grdviewpaymnt.DataBind();
        obj.dr.Close();
    }
    protected void grdviewpaymnt_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(grdviewpaymnt.SelectedRow.Cells[0].Text);
        obj.Query = "SELECT  Payment.*, Payment_type.Pay_type, Customer_request.Reqid AS Expr1 FROM  Payment INNER JOIN Payment_type ON Payment.Pay_typeid = Payment_type.Pay_typeid INNER JOIN  Customer_request ON Payment.Reqid = Customer_request.Reqid where Pid="+id.ToString()+" ";
        obj.GetDataSet(obj.Query);
        dtvwpymnt.DataSource = obj.ds;
        dtvwpymnt.DataBind();
    }
}