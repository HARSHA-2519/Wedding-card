﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Publish_Offrs : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindofrz();
        }
    }
    protected void calndrstrtdate_SelectionChanged(object sender, EventArgs e)
    {
        txtstrtdate.Text = calndrstrtdate.SelectedDate.ToShortDateString();
        calndrstrtdate.Visible = false;
    }
    protected void calndrenddate_SelectionChanged(object sender, EventArgs e)
    {
        txtenddate.Text = calndrenddate.SelectedDate.ToShortDateString();
        calndrenddate.Visible = false;
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table offers.first check whether that record is  is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Offer_Title,Offer from Offers where Offer_Title='" + txtofrtitl.Text + "'and Offer='" + txtofr.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('This Offer Already Exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Offers values('" + txtofrtitl.Text + "','" + txtofr.Text + "','" + txtstrtdate.Text + "','" + txtenddate.Text + "','" + txtstatz.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('offer inserted successfully')</script>");
                bindofrz();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();

    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Publish_Offrs.aspx");
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtofrtitl.Text = "";
        txtofr.Text = "";
        txtstrtdate.Text = "";
        txtenddate.Text = "";
        txtstatz.Text = "";
    }

    protected void cmdcalstrt_Click(object sender, EventArgs e)
    {
        calndrstrtdate.Visible = true;
    }
    protected void cmdcalend_Click(object sender, EventArgs e)
    {
        calndrenddate.Visible = true;
    }
    //bind offers into gridview control.
    protected void bindofrz()
    {
        obj.Query = "select * from Offers";
        obj.SelectData(obj.Query);
        grdvwofrz.DataSource = obj.dr;
        grdvwofrz.DataBind();
        obj.dr.Close();
    }
protected void  grdvwofrz_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
{
    grdvwofrz.EditIndex=-1;
    bindofrz();
}
protected void  grdvwofrz_RowEditing(object sender, GridViewEditEventArgs e)
{
    grdvwofrz.EditIndex=e.NewEditIndex;
    bindofrz();
}
protected void  grdvwofrz_RowDeleting(object sender, GridViewDeleteEventArgs e)
{
    try
    {
        //delete the selected record from the table offers.
        int Offerid = Convert.ToInt32(grdvwofrz.DataKeys[e.RowIndex].Value.ToString());
        obj.Query = "delete from Offers where Offerid=" + Offerid.ToString() + " ";
        obj.WriteData(obj.Query);
        bindofrz();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}
protected void  grdvwofrz_RowUpdating(object sender, GridViewUpdateEventArgs e)
{
    try
    {
        //update the edited details to the table offers.
        int Offerid = Convert.ToInt32(grdvwofrz.DataKeys[e.RowIndex].Value.ToString());
        TextBox txtoftitl = (TextBox)grdvwofrz.Rows[e.RowIndex].FindControl("txtoftitl");
        TextBox txtoffr = (TextBox)grdvwofrz.Rows[e.RowIndex].FindControl("txtoffr");
        TextBox txtstartdt = (TextBox)grdvwofrz.Rows[e.RowIndex].FindControl("txtstartdt");
        TextBox txtenddt = (TextBox)grdvwofrz.Rows[e.RowIndex].FindControl("txtenddt");

        obj.Query = "update Offers set Offer_Title='" + txtoftitl.Text + "', Offer='" + txtoffr.Text + "', Start_dt='" + txtstartdt.Text + "', End_dt='" + txtenddt.Text + "'  where Offerid=" + Offerid + " ";
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Updated')</script>");
        bindofrz();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}

}




