﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Distrct : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindState();
            binddistrct();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new district to the table district.first check whether the district is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Dname from District where Dname='" + txtdname.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<csript>alert('Already Selected')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into District values('" + txtdname.Text + "'," + ddlstate.SelectedValue + ") ";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('District inserted')</script>");
                binddistrct();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //bind state into detailsview control.
    protected void bindState()
    {
        obj.Query = "select * from State";
        obj.SelectData(obj.Query);
        ddlstate.DataSource = obj.dr;
        ddlstate.DataTextField = "Sname";
        ddlstate.DataValueField = "Sid";
        ddlstate.DataBind();
        ddlstate.Items.Insert(0,"--select--");
        obj.dr.Close();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtdname.Text = "";  
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Distrct.aspx");
    }
    //bind state into gridview control.
    protected void binddistrct()
    {
        obj.Query = "SELECT District.*, State.Sname FROM District INNER JOIN State ON District.Sid = State.Sid";
        obj.SelectData(obj.Query);
        grdvwdstrct.DataSource = obj.dr;
        grdvwdstrct.DataBind();
        obj.dr.Close();
    }
    protected void grdvwdstrct_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table district.
            int Did = Convert.ToInt32(grdvwdstrct.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtdistname = (TextBox)grdvwdstrct.Rows[e.RowIndex].FindControl("txtdistname");
            DropDownList sid = (DropDownList)grdvwdstrct.Rows[e.RowIndex].FindControl("ddlsn");
            obj.Query = "update District set Dname='" + txtdistname.Text + "' ,sid=" + sid.SelectedValue + " where Did=" + Did + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            grdvwdstrct.EditIndex = -1;
            binddistrct();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwdstrct_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table district.
            int Did = Convert.ToInt32(grdvwdstrct.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from District where Did=" + Did.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Deleted')</script>");
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwdstrct_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwdstrct.EditIndex = e.NewEditIndex;
        binddistrct();
    }
    protected void grdvwdstrct_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwdstrct.EditIndex = -1;
        binddistrct();
    }
}