﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Colr : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcolr();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new colour to the table colour.first check whether the colour is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select color from colour where color='" + txtcolor.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('selected colour Already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into colour values('" + txtcolor.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('colour selected successfully')</script>");
                bindcolr();
                clear();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Colr.aspx");
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtcolor.Text = "";
    }
    //bind colour  into gridview control.
    protected void bindcolr()
    {
        obj.Query = "select * from Colour";
        obj.SelectData(obj.Query);
        Grdvwcolr.DataSource = obj.dr;
        Grdvwcolr.DataBind();
        obj.dr.Close();
    }

    protected void Grdvwcolr_RowEditing(object sender, GridViewEditEventArgs e)
    {
        Grdvwcolr.EditIndex = e.NewEditIndex;
        bindcolr();
    }
    protected void Grdvwcolr_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        Grdvwcolr.EditIndex = -1;
        bindcolr();
    }
    protected void Grdvwcolr_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int Colrid = Convert.ToInt32(Grdvwcolr.DataKeys[e.RowIndex].Value.ToString());
            //delete the selected record from the table colour.
            obj.Query = "delete from Colour where Colrid=" + Colrid.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Deleted')</script>");
            bindcolr();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void Grdvwcolr_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int Colrid = Convert.ToInt32(Grdvwcolr.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtcolr = (TextBox)Grdvwcolr.Rows[e.RowIndex].FindControl("txtcolr");
            //update the edited details of the table colour.
            obj.Query = "update Colour set Color='" + txtcolr.Text + "' where Colrid=" + Colrid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            Grdvwcolr.EditIndex = -1;
            bindcolr();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    
}