﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Provide_Crd_smpl : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindEvent_type();
            bindFormat();
            bindStyle();
            bindColour();
            bindPrint_Tech();
            bindCard_Suite();
            bindEnvelop_trim_opt();
            bindSignature_collection();
            bindSize();
            bindPapertype();            
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table card sample.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = " select Title from Card_sample where Title='" + txttitle.TemplateControl + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Already Exist')</script>");
            }
            else
            {
                obj.dr.Close();
                filupimg1.SaveAs(Server.MapPath("~/ClubAdmin/CardSample/" + filupimg1.FileName));
                filupimg2.SaveAs(Server.MapPath("~/ClubAdmin/CardSample/" + filupimg2.FileName));
                obj.Query = "insert into Card_sample values('" + txttitle.Text + "'," + ddlevtype.SelectedValue + "," + ddlfrmt.SelectedValue + "," + ddlstyle.SelectedValue + "," + ddlcolr.SelectedValue + "," + ddlprntngtech.SelectedValue + "," + ddlcrdsuit.SelectedValue + "," + ddltrimoptn.SelectedValue + "," + ddlsigntr.SelectedValue + "," + ddlsize.SelectedValue + "," + ddlpaprtyp.SelectedValue + ",'" + filupimg1.FileName + "','" + filupimg2.FileName + "','"+txtprice.Text+"')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('sample card inserted')</script>");
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txttitle.Text = "";
    }
    //bind event type into gridview control.
    protected void bindEvent_type()
    {
        obj.Query = "select * from Event_type";
        obj.SelectData(obj.Query);
        ddlevtype.DataSource = obj.dr;
        ddlevtype.DataTextField = "Ev_type";
        ddlevtype.DataValueField = "Ev_typeid";
        ddlevtype.DataBind();
        ddlevtype.Items.Insert(0,"--select--");
        obj.dr.Close();
    }
    //bind format into gridview control.
    protected void bindFormat()
    {
        obj.Query = "select * from Format";
        obj.SelectData(obj.Query);
        ddlfrmt.DataSource = obj.dr;
        ddlfrmt.DataTextField = "Formatname";
        ddlfrmt.DataValueField = "Formatid";
        ddlfrmt.DataBind();
        ddlfrmt.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind style into gridview control.
    protected void bindStyle()
    {
        obj.Query = "select * from Style";
        obj.SelectData(obj.Query);
        ddlstyle.DataSource = obj.dr;
        ddlstyle.DataTextField = "Style";
        ddlstyle.DataValueField = "Styleid";
        ddlstyle.DataBind();
        ddlstyle.Items.Insert(0,"--select--");
        obj.dr.Close();
    }
    //bind colour into gridview control.
    protected void bindColour()
    {
        obj.Query = "select * from colour";
        obj.SelectData(obj.Query);
        ddlcolr.DataSource = obj.dr;
        ddlcolr.DataTextField = "Color";
        ddlcolr.DataValueField = "Colrid";
        ddlcolr.DataBind();
        ddlcolr.Items.Insert(0,"--select--");
        obj.dr.Close();
    }
    //bind printing technology into gridview control.
    protected void bindPrint_Tech()
    {
        obj.Query = "select * from Print_Tech";
        obj.SelectData(obj.Query);
        ddlprntngtech.DataSource = obj.dr;
        ddlprntngtech.DataTextField = "Tech";
        ddlprntngtech.DataValueField = "Print_techid";
        ddlprntngtech.DataBind();
        ddlprntngtech.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind card suite into gridview control.
    protected void bindCard_Suite()
    {
        obj.Query = "select * from Card_Suite";
        obj.SelectData(obj.Query);
        ddlcrdsuit.DataSource = obj.dr;
        ddlcrdsuit.DataTextField = "Suite";
        ddlcrdsuit.DataValueField = "Card_suid";
        ddlcrdsuit.DataBind();
        ddlcrdsuit.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind envelop trim option into gridview control.
    protected void bindEnvelop_trim_opt()
    {
        obj.Query = "select * from Envelop_trim_opt";
        obj.SelectData(obj.Query);
        ddltrimoptn.DataSource = obj.dr;
        ddltrimoptn.DataTextField = "Trim_Option";
        ddltrimoptn.DataValueField = "Trim_Optid";
        ddltrimoptn.DataBind();
        ddltrimoptn.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind signature collection into gridview control.
    protected void bindSignature_collection()
    {
        obj.Query = "select * from Signature_collection";
        obj.SelectData(obj.Query);
        ddlsigntr.DataSource = obj.dr;
        ddlsigntr.DataTextField = "Signature";
        ddlsigntr.DataValueField = "Signid";
        ddlsigntr.DataBind();
        ddlsigntr.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind size into gridview control.
    protected void bindSize()
    {
        obj.Query = "select * from Size";
        obj.SelectData(obj.Query);
        ddlsize.DataSource = obj.dr;
        ddlsize.DataTextField = "Dimension";
        ddlsize.DataValueField = "Sizeid";
        ddlsize.DataBind();
        ddlsize.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind paper typeinto gridview control.
    protected void bindPapertype()
    {
        obj.Query = "select * from Papertype";
        obj.SelectData(obj.Query);
        ddlpaprtyp.DataSource = obj.dr;
        ddlpaprtyp.DataTextField = "Type";
        ddlpaprtyp.DataValueField = "Paper_Typeid";
        ddlpaprtyp.DataBind();
        ddlpaprtyp.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Provide_Crd_smpl.aspx");
    }    
}