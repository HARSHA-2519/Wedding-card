﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Paymnt_typ : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/login.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindpaymnttype();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new payment type to the table payment type.first check whether that type is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Pay_type from Payment_type where Pay_type='" + txtpaymnttyp.Text + "'";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Payment Type Already Selected,Choose Another One')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Payment_type values('" + txtpaymnttyp.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Payment type inserted')</script>");
                bindpaymnttype();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        finally
        {
            obj.con.Close();
            obj.con.Dispose();
            obj.cmd.Dispose();
        }
        clear();
    }
    protected void clear()
    {
        txtpaymnttyp.Text = "";
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Paymnt_typ.aspx");
    }
    //bind payment type into gridview control.
    protected void bindpaymnttype()
    {
        obj.Query = "select * from Payment_type";
        obj.SelectData(obj.Query);
        grdvwpaytype.DataSource = obj.dr;
        grdvwpaytype.DataBind();
        obj.dr.Close();
    }
    protected void grdvwpaytype_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details of the table payment type.
            int Pay_typeid = Convert.ToInt32(grdvwpaytype.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtpytyp = (TextBox)grdvwpaytype.Rows[e.RowIndex].FindControl("txtpytyp");
            obj.Query = "update Payment_type set Pay_type='" + txtpytyp.Text + "' where Pay_typeid=" + Pay_typeid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data updated')</script>");
            bindpaymnttype();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwpaytype_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwpaytype.EditIndex = e.NewEditIndex;
        bindpaymnttype();
    }
    protected void grdvwpaytype_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table payment type.
            int Pay_typeid = Convert.ToInt32(grdvwpaytype.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Payment_type where Pay_typeid=" + Pay_typeid.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data deleted')</script>");
            bindpaymnttype();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwpaytype_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwpaytype.EditIndex = -1;
        bindpaymnttype();
    }
}