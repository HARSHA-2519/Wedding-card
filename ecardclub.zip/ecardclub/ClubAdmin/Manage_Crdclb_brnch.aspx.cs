﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Crdclb_brnch : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindDistrict();  
        }
    }
    protected void cmdcancl_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Crdclb_brnch.aspx");
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtadres.Text = "";
        txtcntctno.Text = "";
        txtcntctprsn.Text = "";
        txtemail.Text = "";
        txtstatz.Text = "";
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new card club to the table .first check whether the  card club is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Branch,Address from Card_club_branch where Branch='" + txtbrnch.Text + "' and Address='" + txtadres.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Card_club_branch values('" + txtbrnch.Text + "','" + txtadres.Text + "'," + ddldistrct.SelectedValue + "," + txtcntctno.Text + ",'" + txtcntctprsn.Text + "','" + txtemail.Text + "','" + txtstatz.Text + "','" + System.DateTime.Now.ToString("MM/dd/yy") + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('branch inserted')</script>");
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //bind district into gridview control.
    protected void bindDistrict()
    {
        obj.Query = "select * from District";
        obj.SelectData(obj.Query);
        ddldistrct.DataSource = obj.dr;
        ddldistrct.DataTextField = "Dname";
        ddldistrct.DataValueField = "Did";
        ddldistrct.DataBind();
        ddldistrct.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
}


   