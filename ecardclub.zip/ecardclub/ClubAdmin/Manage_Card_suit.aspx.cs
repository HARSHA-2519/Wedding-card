﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Card_suit : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcardsuit();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new card suite to the table card suite.first check whether that card suite is already exist or not
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Suite from Card_Suite where Suite='" + txtsuite.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('card suite already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Card_Suite values('" + txtsuite.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('card suite inserted successfully')</script>");
                bindcardsuit();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Card_suit.aspx");
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtsuite.Text = "";
    }
    //bind card suite into gridview.
    protected void bindcardsuit()
    {
        obj.Query = "select * from Card_Suite";
        obj.SelectData(obj.Query);
        grdvwcrdsuit.DataSource = obj.dr;
        grdvwcrdsuit.DataBind();
        obj.dr.Close();
    }
    protected void grdvwcrdsuit_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details of the table card suite.
            int Card_suid = Convert.ToInt32(grdvwcrdsuit.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtsuit = (TextBox)grdvwcrdsuit.Rows[e.RowIndex].FindControl("txtsuit");
            obj.Query = "update Card_Suite set Suite='" + txtsuit.Text + "' where Card_suid=" + Card_suid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data updated')</script>");
            grdvwcrdsuit.EditIndex = -1;
            bindcardsuit();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwcrdsuit_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwcrdsuit.EditIndex = e.NewEditIndex;
        bindcardsuit();
    }
    protected void grdvwcrdsuit_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //delete data from the table card suite
        int Card_suid=Convert.ToInt32(grdvwcrdsuit.DataKeys[e.RowIndex].Value.ToString());
        obj.Query = "delete from Card_Suite where Card_suid="+Card_suid.ToString()+" ";
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('data deleted')</script>");
        bindcardsuit();
    }
    protected void grdvwcrdsuit_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwcrdsuit.EditIndex = -1;
        bindcardsuit();
    }   
}