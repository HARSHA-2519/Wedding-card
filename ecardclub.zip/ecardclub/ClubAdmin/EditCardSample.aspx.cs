﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_EditCardSample : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcrdsmpl();
        }

    }
    //bind card sample into detailsview
    protected void bindcrdsmpl()
    {
        obj.Query = "SELECT Card_sample.*, Event_type.Ev_type, Format.Formatname, Style.Style, Colour.Color, Print_Tech.Tech, Card_Suite.Suite, Envelop_trim_opt.Trim_Option,Signature_collection.Signature, Size.Dimension, Papertype.Type FROM Card_sample INNER JOIN Event_type ON Card_sample.Ev_typeid = Event_type.Ev_typeid INNER JOIN Format ON Card_sample.Formatid = Format.Formatid INNER JOIN Style ON Card_sample.Styleid = Style.Styleid INNER JOIN Colour ON Card_sample.Colrid = Colour.Colrid INNER JOIN Print_Tech ON Card_sample.Print_techid = Print_Tech.Print_techid INNER JOIN Card_Suite ON Card_sample.Card_suid = Card_Suite.Card_suid INNER JOIN Envelop_trim_opt ON Card_sample.Trim_Optid = Envelop_trim_opt.Trim_Optid INNER JOIN Signature_collection ON Card_sample.Signid = Signature_collection.Signid INNER JOIN Size ON Card_sample.Sizeid = Size.Sizeid INNER JOIN Papertype ON Card_sample.Paper_Typeid = Papertype.Paper_Typeid";
        obj.GetDataSet(obj.Query);
        DtCardSample.DataSource = obj.ds;
        DtCardSample.DataBind();
    }
    protected void DtCardSample_ModeChanging(object sender, DetailsViewModeEventArgs e)
    {
        DtCardSample.ChangeMode ( e.NewMode);
        bindcrdsmpl();
    }
    protected void DtCardSample_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details of card sample
            string img1, img2;
            int Sampleid = Convert.ToInt32(DtCardSample.DataKey.Value.ToString());
            TextBox txttitle = (TextBox)DtCardSample.FindControl("txttitle");
            DropDownList ddlevnttype = (DropDownList)DtCardSample.FindControl("ddlevnttype");
            DropDownList ddlcrdfrmt = (DropDownList)DtCardSample.FindControl("ddlcrdfrmt");
            DropDownList ddlstyle = (DropDownList)DtCardSample.FindControl("ddlstyle");
            DropDownList ddlclr = (DropDownList)DtCardSample.FindControl("ddlclr");
            DropDownList ddlpritech = (DropDownList)DtCardSample.FindControl("ddlpritech");
            DropDownList ddlcdsuit = (DropDownList)DtCardSample.FindControl("ddlcdsuit");
            DropDownList ddltrmopt = (DropDownList)DtCardSample.FindControl("ddltrmopt");
            DropDownList ddlsign = (DropDownList)DtCardSample.FindControl("ddlsign");
            DropDownList ddlsiz = (DropDownList)DtCardSample.FindControl("ddlsiz");
            DropDownList ddlpprtyp = (DropDownList)DtCardSample.FindControl("ddlpprtyp");          
            FileUpload fpimg1 = (FileUpload)DtCardSample.FindControl("fpimg1");
            FileUpload fpimg2 = (FileUpload)DtCardSample.FindControl("fpimg2");
            TextBox txtimg1 = (TextBox)DtCardSample.FindControl("txtimg1");
            TextBox txtimg2 = (TextBox)DtCardSample.FindControl("txtimg2");
            if (fpimg1.HasFile)
            {
                fpimg1.SaveAs(Server.MapPath("~/ClubAdmin/CardSample/" + fpimg1.FileName));
                img1 = fpimg1.FileName;
            }
            else
            {
                img1 = txtimg1.Text;
            }
            if (fpimg2.HasFile)
            {
                fpimg2.SaveAs(Server.MapPath("~/ClubAdmin/CardSample/" + fpimg2.FileName));
                img2 = txtimg2.Text;
            }
            else
            {
                img2 = txtimg2.Text;
            }
            TextBox txtprice = (TextBox)DtCardSample.FindControl("txtprice");
            obj.Query = "update Card_sample set Title='" + txttitle.Text + "',Ev_typeid=" + ddlevnttype.SelectedValue + ",Formatid=" + ddlcrdfrmt.SelectedValue + ",Styleid=" + ddlstyle.SelectedValue + ",Colrid=" + ddlclr.SelectedValue + ",Print_techid=" + ddlpritech.SelectedValue + ",Card_suid=" + ddlcdsuit.SelectedValue + ",Trim_Optid=" + ddltrmopt.SelectedValue + ",Signid=" + ddlsign.SelectedValue + ",Sizeid=" + ddlsiz.SelectedValue + ",Paper_Typeid=" + ddlpprtyp.SelectedValue + ",Price='"+txtprice.Text+"',Img1='" + img1 + "',Img2='" + img2 + "' where Sampleid=" + Sampleid + " ";
            DtCardSample.ChangeMode(DetailsViewMode.ReadOnly);
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            bindcrdsmpl();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void DtCardSample_ItemDeleting(object sender, DetailsViewDeleteEventArgs e)
    {
        //delete data from the table card sample
        int Sampleid = Convert.ToInt32(DtCardSample.DataKey.Value.ToString());
        obj.Query = "delete from Card_sample where Sampleid="+Sampleid.ToString()+" ";
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Deleted')</script>");
        bindcrdsmpl();
    }
    protected void DtCardSample_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {
        DtCardSample.PageIndex = e.NewPageIndex;
        bindcrdsmpl();
    }
}