﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Activate_Crd_rqst : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
          
            bindcustreq();
        }
    }
    protected void bindcustreq()
    {
        obj.Query = "SELECT Customer_request.*, Customer.Cname, Card_sample.Title, Shipment_mode.Shipmt_mode, Event_type.Ev_type FROM Customer_request INNER JOIN Customer ON Customer_request.Cid = Customer.Cid INNER JOIN Shipment_mode ON Customer_request.Shipmtid = Shipment_mode.Shipmtid INNER JOIN Event_type ON Customer_request.Ev_typeid = Event_type.Ev_typeid INNER JOIN Card_sample ON Customer_request.Sampleid = Card_sample.Sampleid";
        obj.SelectData(obj.Query);
        grdvwactcust.DataSource = obj.dr;
        grdvwactcust.DataBind();
        obj.dr.Close();
    }
    protected void grdvwactcust_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(grdvwactcust.SelectedRow.Cells[0].Text);
        obj.Query = "SELECT Customer_request.*, Customer.Cname, Card_sample.Title, Shipment_mode.Shipmt_mode, Event_type.Ev_type FROM Customer_request INNER JOIN Customer ON Customer_request.Cid = Customer.Cid INNER JOIN Shipment_mode ON Customer_request.Shipmtid = Shipment_mode.Shipmtid INNER JOIN Event_type ON Customer_request.Ev_typeid = Event_type.Ev_typeid INNER JOIN Card_sample ON Customer_request.Sampleid = Card_sample.Sampleid where reqid="+id+"";
        obj.GetDataSet(obj.Query);
        dtcrdreq.DataSource = obj.ds;
        dtcrdreq.DataBind();
        obj.ds.Clear();

    }

    protected void dtcrdreq_ItemCommand(object sender, DetailsViewCommandEventArgs e)
    {
        int id=Convert.ToInt32(dtcrdreq.DataKey.Value.ToString());
        if (e.CommandName == "Activate")
        {
            obj.Query = "update Customer_request set Status='Valid' where Reqid ='" + id + "' ";
            obj.WriteData(obj.Query);
            bindcustreq();
            Response.Write("<script>alert('Card Request Activated')</script>");
        }
    }
}