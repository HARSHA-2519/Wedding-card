﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Editcdclubbrnch : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            binddist();
        }
    }
    //bind district into detailsview
    protected void binddist()
    {
        obj.Query = "SELECT Card_club_branch.*, District.Dname FROM Card_club_branch INNER JOIN District ON Card_club_branch.Did = District.Did";
        obj.GetDataSet(obj.Query);
        dtcrdbrnch.DataSource = obj.ds;
        dtcrdbrnch.DataBind();
        
    }
     
protected void  dtcrdbrnch_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
{
   dtcrdbrnch.PageIndex = e.NewPageIndex;
    binddist();
}
protected void  dtcrdbrnch_ModeChanging(object sender, DetailsViewModeEventArgs e)
{
    dtcrdbrnch.ChangeMode(e.NewMode);
    binddist();
}
protected void  dtcrdbrnch_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
{
    try
    {
        //update the edited details of cardclub branch
        int Clubid = Convert.ToInt32(dtcrdbrnch.DataKey.Value.ToString());
        TextBox txtbrnch = (TextBox)dtcrdbrnch.FindControl("txtbrnch");
        TextBox txtadres = (TextBox)dtcrdbrnch.FindControl("txtadres");
        DropDownList ddldname = (DropDownList)dtcrdbrnch.FindControl("ddldname");
        TextBox txtcontno = (TextBox)dtcrdbrnch.FindControl("txtcontno");
        TextBox txtcontpersn = (TextBox)dtcrdbrnch.FindControl("txtcontpersn");
        TextBox txtemail = (TextBox)dtcrdbrnch.FindControl("txtemail");
        TextBox txtstats = (TextBox)dtcrdbrnch.FindControl("txtstats");
        obj.Query = "update Card_club_branch set Branch='" + txtbrnch.Text + "',Address='" + txtadres.Text + "',Did=" + ddldname.SelectedValue + ",Cont_no='" + txtcontno.Text + "',Cont_person='" + txtcontpersn.Text + "',Email='" + txtemail.Text + "' where Clubid=" + Clubid + " ";
        dtcrdbrnch.ChangeMode(DetailsViewMode.ReadOnly);
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Updated')</script>");
        binddist();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}
protected void  dtcrdbrnch_ItemDeleting(object sender, DetailsViewDeleteEventArgs e)
{
    //delete data from the table cardclub branch
    int Cid = Convert.ToInt32(dtcrdbrnch.DataKey.Value.ToString());
    obj.Query = "delete from Customer where Cid=" +Cid .ToString() + " ";
    obj.WriteData(obj.Query);
    Response.Write("<script>alert('Data Deleted')</script>");
    binddist();

}
}