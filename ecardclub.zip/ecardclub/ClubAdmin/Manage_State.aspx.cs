﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_State : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindstate();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table state.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Sname from State where Sname='" + txtstate.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Current state already selected')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into State values('" + txtstate.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('State inserted')</script>");
                bindstate();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtstate.Text = "";
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_State.aspx");
    }
    //bind state into gridview control.
    protected void bindstate()
    {
        obj.Query = "select * from State";
        obj.SelectData(obj.Query);
        grdvwstate.DataSource = obj.dr;
        grdvwstate.DataBind();
        obj.dr.Close();
    }
    protected void grdvwstate_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table state.
            int Sid = Convert.ToInt32(grdvwstate.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtstat = (TextBox)grdvwstate.Rows[e.RowIndex].FindControl("txtstat");
            obj.Query = "update State set Sname='" + txtstat.Text + "' where Sid=" + Sid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            bindstate();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwstate_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table state.
            int Sid = Convert.ToInt32(grdvwstate.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from State where Sid=" + Sid.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data  Deleted')</script>");
            bindstate();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwstate_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwstate.EditIndex = e.NewEditIndex;
        bindstate();
    }
    protected void grdvwstate_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwstate.EditIndex = -1;
        bindstate();
    }
}