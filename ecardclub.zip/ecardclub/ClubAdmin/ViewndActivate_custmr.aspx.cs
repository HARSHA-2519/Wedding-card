﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_ViewndActivate_custmr : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {          
            bindcustmer();
        }
    }   
    protected void bindcustmer()
    {
        obj.Query = "SELECT Cid, Cname, Reg_date FROM Customer";
        obj.SelectData(obj.Query);
        grdvwcustmr.DataSource = obj.dr;
        grdvwcustmr.DataBind();
        obj.dr.Close();
    }
    protected void grdvwcustmr_SelectedIndexChanged(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(grdvwcustmr.SelectedRow.Cells[0].Text);
        obj.Query = "SELECT Customer.*, District.Dname FROM Customer INNER JOIN District ON Customer.Did = District.Did where cid="+id.ToString()+"";
        obj.GetDataSet(obj.Query);
        dtcustmr.DataSource = obj.ds;
        dtcustmr.DataBind();
    }
    protected void dtcustmr_ItemCommand(object sender, DetailsViewCommandEventArgs e)
    {
        int Cid=Convert.ToInt32(dtcustmr.DataKey.Value.ToString());
        if (e.CommandName == "Activate")
        {
            obj.Query = "update Customer set Status='Valid' where Cid='"+Cid+"' ";
            obj.WriteData(obj.Query);
            bindcustmer();
            Response.Write("<script>alert('Customer Activated')</script>");
        }
    }
}