﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Papr_typ : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
       {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindpaprtype();

        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new paper type to the table papertype.first check whether that paper type is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Type from Papertype where Type='" + txttyp.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Paper Type Already Exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Papertype values('" + txttyp.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Paper Type Inserted')</script>");
                bindpaprtype();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txttyp.Text = "";
    }
    //bind papertype into gridview control.
    protected void bindpaprtype()
    {
        obj.Query = "select * from Papertype";
        obj.SelectData(obj.Query);
        grdvwpaprtyp.DataSource = obj.dr;
        grdvwpaprtyp.DataBind();
        obj.dr.Close();
    }
    protected void grdvwpaprtyp_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table papertype.
            int Paper_Typeid = Convert.ToInt32(grdvwpaprtyp.DataKeys[e.RowIndex].Value.ToString());
            TextBox txttype = (TextBox)grdvwpaprtyp.Rows[e.RowIndex].FindControl("txttype");
            obj.Query = "update Papertype set Type='" + txttype.Text + "' where Paper_Typeid=" + Paper_Typeid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data updated')</script>");
            bindpaprtype();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwpaprtyp_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwpaprtyp.EditIndex = e.NewEditIndex;
        bindpaprtype();
    }
    protected void grdvwpaprtyp_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table papertype.
            int Paper_Typeid = Convert.ToInt32(grdvwpaprtyp.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Papertype where Paper_Typeid=" + Paper_Typeid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data deleted')</script>");
            bindpaprtype();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwpaprtyp_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwpaprtyp.EditIndex = -1;
        bindpaprtype();
    }
}