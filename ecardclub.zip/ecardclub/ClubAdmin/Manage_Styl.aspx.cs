﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Styl : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindstyl();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table style.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Style from Style Where Style='" + txtstyl.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('This Style Already Selected')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Style values('" + txtstyl.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('style inserted')</script>");
                bindstyl();

            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtstyl.Text = "";
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Styl.aspx");
    }
    //bind style into gridview control.
    protected void bindstyl()
    {
        obj.Query = "select * from Style";
        obj.SelectData(obj.Query); grdvwstyle.DataSource = obj.dr;
        grdvwstyle.DataBind();
        obj.dr.Close();
    }
    protected void grdvwstyle_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwstyle.EditIndex = e.NewEditIndex;
        bindstyl();
    }
    protected void grdvwstyle_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwstyle.EditIndex = -1;
        bindstyl();
    }
    protected void grdvwstyle_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table style.
            int Styleid = Convert.ToInt32(grdvwstyle.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtstyle = (TextBox)grdvwstyle.Rows[e.RowIndex].FindControl("txtstyle");
            obj.Query = "update Style set Style='" + txtstyle.Text + "' where Styleid=" + Styleid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            bindstyl();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwstyle_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table style.
            int Styleid = Convert.ToInt32(grdvwstyle.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Style where Styleid=" + Styleid.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Deleted')</script>");
            bindstyl();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
}