﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Envlp_trm_optns : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindenvlptrim();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new trim option to the table envelope trim option.first check whether the trim option is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Trim_Option from Envelop_trim_opt where Trim_Option='" + txttrmoptn.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Selected Trim Option Already Exist Choose another One')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Envelop_trim_opt values('" + txttrmoptn.Text + "') ";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Trim Option inserted')</script>");
                bindenvlptrim();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Envlp_trm_optns.aspx");
    }
    //bind envelope trim option into gridview control.
    protected void bindenvlptrim()
    {
        obj.Query = "select * from Envelop_trim_opt";
        obj.SelectData(obj.Query);
        grdvwenvlptrm.DataSource = obj.dr;
        grdvwenvlptrm.DataBind();
        obj.dr.Close();
    }
    protected void grdvwenvlptrm_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwenvlptrm.EditIndex = -1;
        bindenvlptrim();
    }
    protected void grdvwenvlptrm_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected from the table envelope trim option.
            int Trim_Optid = Convert.ToInt32(grdvwenvlptrm.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Envelop_trim_opt where Trim_Optid=" + Trim_Optid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data deleted')</script>");
            bindenvlptrim();

        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwenvlptrm_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwenvlptrm.EditIndex = e.NewEditIndex;
        bindenvlptrim();

    }
    protected void grdvwenvlptrm_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table envelope trim option.
            int Trim_Optid = Convert.ToInt32(grdvwenvlptrm.DataKeys[e.RowIndex].Value.ToString());
            TextBox txttrimopn = (TextBox)grdvwenvlptrm.Rows[e.RowIndex].FindControl("txttrimopn");
            obj.Query = "update Envelop_trim_opt set Trim_Option='" + txttrimopn.Text + "' where Trim_Optid=" + Trim_Optid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data updated')</script>");
            bindenvlptrim();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void cmdcancel_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Envlp_trm__optns.aspx");
    }
}