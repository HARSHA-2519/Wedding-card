﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Frmt : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindfrmt();
        }
    }
    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Frmt.aspx");
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new format of card to the table format.first check whether the inserted format is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Formatname,Img_shape from Format where Formatname='" + txtfrmtname.Text + "' and Img_shape='" + txtimgshp.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Entered format and image shape are already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Format values('" + txtfrmtname.Text + "','" + txtimgshp.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Successfully inserted')</script>");
                bindfrmt();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtfrmtname.Text = "";
        txtimgshp.Text = "";
    }
    //bind format into gridview control.
    protected void bindfrmt()
    {
        obj.Query = "select * from Format";
        obj.SelectData(obj.Query);
        grdvwfrmt.DataSource = obj.dr;
        grdvwfrmt.DataBind();
        obj.dr.Close();
    }
protected void  grdvwfrmt_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
{
    grdvwfrmt.EditIndex=-1;
    bindfrmt();
}
protected void  grdvwfrmt_RowEditing(object sender, GridViewEditEventArgs e)
{
    grdvwfrmt.EditIndex=e.NewEditIndex;
    bindfrmt();
}
protected void  grdvwfrmt_RowDeleting(object sender, GridViewDeleteEventArgs e)
{
    try
    {
        //delete the selected record from the table format.
        int Formatid = Convert.ToInt32(grdvwfrmt.DataKeys[e.RowIndex].Value.ToString());
        obj.Query = "delete from Format where Formatid=" + Formatid.ToString() + " ";
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Deleted')</script>");
        bindfrmt();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}
protected void  grdvwfrmt_RowUpdating(object sender, GridViewUpdateEventArgs e)
{
    try
    {
        //update the edited details to the table format.
        int Formatid = Convert.ToInt32(grdvwfrmt.DataKeys[e.RowIndex].Value.ToString());
        TextBox txtfrname = (TextBox)grdvwfrmt.Rows[e.RowIndex].FindControl("txtfrname");
        TextBox txtimshp = (TextBox)grdvwfrmt.Rows[e.RowIndex].FindControl("txtimshp");
        obj.Query = "update Format set Formatname='" + txtfrname.Text + "',Img_shape='" + txtimshp.Text + "' where Formatid=" + Formatid + " ";
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Updated')</script>");
        bindfrmt();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}
}
