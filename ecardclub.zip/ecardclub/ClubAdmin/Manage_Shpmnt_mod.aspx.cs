﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_Manage_Shpmnt_mod : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Admin"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindshpmtmd();
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table shipment mode.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Shipmt_mode from Shipment_mode where Shipmt_mode='" + txtshpmntmod.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Shipment Mode Already Exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Shipment_mode values('" + txtshpmntmod.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Shipment Mode inserted')</script>");
                bindshpmtmd();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
        }
    //clear all fields after submission.
    protected void clear()
    {
        txtshpmntmod.Text = "";
    }
    //bind shipment mode into gridview control.
    protected void bindshpmtmd()
    {
        obj.Query = "select * from Shipment_mode";
        obj.SelectData(obj.Query);
        grdvwshpmd.DataSource = obj.dr;
        grdvwshpmd.DataBind();
        obj.dr.Close();   
    }
    protected void grdvwshpmd_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwshpmd.EditIndex = -1;
        bindshpmtmd();
    }
    protected void grdvwshpmd_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwshpmd.EditIndex = e.NewEditIndex;
        bindshpmtmd();
    }
    protected void grdvwshpmd_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details of the table shipment mode.
            int Shipmtid = Convert.ToInt32(grdvwshpmd.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtshpmd = (TextBox)grdvwshpmd.Rows[e.RowIndex].FindControl("txtshpmd");
            obj.Query = "update Shipment_mode set Shipmt_mode='" + txtshpmd.Text + "' where Shipmtid=" + Shipmtid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Updated')</script>");
            bindshpmtmd();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwshpmd_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table shipment mode.
            int Shipmtid = Convert.ToInt32(grdvwshpmd.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Shipment_mode where Shipmtid=" + Shipmtid.ToString() + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('Data Deleted')</script>");
            bindshpmtmd();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }

    protected void cmdcancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/Manage_Shpmnt_mod.aspx");
    }
}