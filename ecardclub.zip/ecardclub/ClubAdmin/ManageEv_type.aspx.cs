﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ClubAdmin_ManageEv_type : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
       if (HttpContext.Current.Session["Admin"] == null)
       {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindevtyp();
        }
    }

    protected void CmdSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table event type.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Ev_type from Event_type where Ev_type='" + txtevtype.Text + "' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Selected event already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Event_type values('" + txtevtype.Text + "')";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Event Inserted')</script>");
                bindevtyp();
            }
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
        clear();
    }
    protected void CmdCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ClubAdmin/ManageEv_type.aspx");
    }
    //clear all fields after submission.
    protected void clear()
    {
        txtevtype.Text = "";
    }
    //bind event type into gridview control.
    protected void bindevtyp()
    {
        obj.Query = "select * from Event_type";
        obj.SelectData(obj.Query);
        grdvwevtype.DataSource = obj.dr;
        grdvwevtype.DataBind();
        obj.dr.Close();
    }
    protected void grdvwevtype_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //update the edited details to the table event type.
            int Ev_typeid = Convert.ToInt32(grdvwevtype.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtevtyp = (TextBox)grdvwevtype.Rows[e.RowIndex].FindControl("txtevtyp");
            obj.Query = "update Event_type set Ev_type='" + txtevtyp.Text + "' where Ev_typeid=" + Ev_typeid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data upated')</script>");
            bindevtyp();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwevtype_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdvwevtype.EditIndex = e.NewEditIndex;
        bindevtyp();
    }
    protected void grdvwevtype_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            //delete the selected record from the table event type.
            int Ev_typeid = Convert.ToInt32(grdvwevtype.DataKeys[e.RowIndex].Value.ToString());
            obj.Query = "delete from Event_type where Ev_typeid=" + Ev_typeid + " ";
            obj.WriteData(obj.Query);
            Response.Write("<script>alert('data deleted')</script>");
            bindevtyp();
        }
        catch (Exception ex)
        {
            lblmsg.Text = ex.ToString();
        }
    }
    protected void grdvwevtype_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdvwevtype.EditIndex = -1;
        bindevtyp();
    }
}