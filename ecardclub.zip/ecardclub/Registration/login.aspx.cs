﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration_login : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        obj.connect();
    }
    protected void btnsignin_Click(object sender, EventArgs e)
    {
        obj.Query = "select * from Admin where Username='" + txtusrname.Text + "' and Password='" + txtpwd.Text + "'";
        obj.SelectData(obj.Query);
        if (obj.dr.Read())
        {
            obj.dr.Close();
            Session["admin"] = txtusrname.Text;
            Response.Redirect("~/ClubAdmin/AdminHome.aspx");
        }
        else
        {
            obj.dr.Close();
            obj.Query = "select * from Customer where Username='" + txtusrname.Text + "' and Password='" + txtpwd.Text + "' ";
            obj.SelectData(obj.Query);
        }
        if (obj.dr.Read())
        {
            Session["Customer"] = txtusrname.Text;
            Session["Cid"] = obj.dr[0].ToString();
            Session["Cname"] = obj.dr[1].ToString();
            Response.Redirect("~/Customer/CustomerHome.aspx");
        }
        else
        {
            lblmsg.Text = "Enter a valid username and password";
        }
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Registration/login.aspx");
    }
    protected void btnsignup_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Registration/Custmr_Reg.aspx");
    }
}