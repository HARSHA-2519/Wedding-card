﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_Customer_req : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    int totalprice, sampleid, noc, shpmnt, price, shpprice, cid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
           Response.Redirect("~/Registration/Home.aspx");
        }
       else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcustmr();
            bindcrdsmpl();
            bindshpmnt();
            bindevnttype(); 
        }
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table customer request.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Cid,Want_date from Customer_request where Cid=" + ddlcustmr.SelectedValue + " and Want_date='" + txtwntdate.Text + "'";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('Request Already Exist')</script>");
            }
            else
            {
                obj.dr.Close();
                
                int totprice=calprice();
                obj.Query = "insert into Customer_request values(" + ddlcustmr.SelectedValue + "," + ddlsamplcrd.SelectedValue + ",'" + txtnoofcpy.Text + "','" + txtwntdate.Text + "','" + System.DateTime.Now.ToString("MM/dd/yy") + "','Invalid'," + ddlshpmnt.SelectedValue + ",'" + txtshpmntadrs.Text + "'," + ddlevtyp.SelectedValue + ",'" + txtbridname.Text + "','" + txtgrmname.Text + "','" + txtadrs.Text + "','" + txtcntnt.Text + "','" + txtevntdat.Text + "','" + txtevtym.Text + "','" + txtvenue.Text + "'," + totprice + ")";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Event Inserted,Total Price="+totalprice+"')</script>");
            }   
       }
        catch (Exception ex)
        {
           lblmsg.Text = ex.ToString();
        }
        clear();
    }
    public int calprice()
    {
        
        cid = Convert.ToInt32(ddlcustmr.SelectedValue.ToString());
        sampleid = Convert.ToInt32(ddlsamplcrd.SelectedValue.ToString());
        noc = Convert.ToInt32(txtnoofcpy.Text);
        shpmnt = Convert.ToInt32(ddlshpmnt.SelectedValue.ToString());
        obj.Query="select Price from Card_sample where Sampleid="+sampleid+"";
        obj.SelectData(obj.Query);
        if(obj.dr.Read())
        price = Convert.ToInt32(obj.dr[0].ToString());
        obj.dr.Close();
        obj.Query = "select * from Shipment_mode where Shipmtid=" + shpmnt + "";
        obj.SelectData(obj.Query);
        obj.dr.Read();
        int shipmode = Convert.ToInt32(obj.dr[0].ToString());
        if (shipmode == 1)
            shpprice = 120;
        else if (shipmode == 2)
            shpprice = 150;
        else
            shpprice = 100;
        totalprice = noc * price + shpprice;
        obj.dr.Close();
        return totalprice;
        //int Reqid;
        //obj.Query="select Max(Reqid) from Customer_request";
        //    obj.SelectData(obj.Query);
        //    if (obj.dr.Read())
        //    {
        //        Reqid = Convert.ToInt32(obj.dr[0].ToString());
        //        obj.dr.Close();
        //        obj.Query = "update Customer_request set Tot_price=" + totalprice + " where Reqid=" + Reqid + " ";
        //        obj.WriteData(obj.Query);
        //    }
        //    else
        //    {
        //        obj.dr.Close();
        //        Response.Write("<script>alert('Error in request id')</script>");
        //    }
    }
    //clear all fields after submission.

    protected void clear()
    {
        txtnoofcpy.Text = "";
        txtwntdate.Text = "";
        txtshpmntadrs.Text = "";
        txtbridname.Text = "";
        txtgrmname.Text = "";
        txtadrs.Text = "";
        txtcntnt.Text = "";
        txtevntdat.Text = "";
        txtevtym.Text = "";
        txtvenue.Text = "";
    }
    //bind shipment mode into detailsview control.
    protected void bindshpmnt()
    {
        obj.Query = "select * from Shipment_mode";
        obj.SelectData(obj.Query);
        ddlshpmnt.DataSource = obj.dr;
        ddlshpmnt.DataTextField = "Shipmt_mode";
        ddlshpmnt.DataValueField = "Shipmtid";
        ddlshpmnt.DataBind();
        ddlshpmnt.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind customer into detailsview control.
    protected void bindcustmr()
    {
        obj.Query = "select * from Customer";
        obj.SelectData(obj.Query);
        ddlcustmr.DataSource = obj.dr;
        ddlcustmr.DataTextField = "Cname";
        ddlcustmr.DataValueField = "Cid";
        ddlcustmr.DataBind();
        ddlcustmr.Items.Insert(0,"--select--");
        obj.dr.Close();
    }
    //bind card sample into detailsview control.
    protected void bindcrdsmpl()
    {
        obj.Query = "select * from Card_sample";
        obj.SelectData(obj.Query);
        ddlsamplcrd.DataSource = obj.dr;
        ddlsamplcrd.DataTextField = "Title";
        ddlsamplcrd.DataValueField = "Sampleid";
        ddlsamplcrd.DataBind();
        ddlsamplcrd.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //bind event type into detailsview control.
    protected void bindevnttype()
    {
        obj.Query = "select * from Event_type";
        obj.SelectData(obj.Query);
        ddlevtyp.DataSource = obj.dr;
        ddlevtyp.DataTextField = "Ev_type";
        ddlevtyp.DataValueField = "Ev_typeid";
        ddlevtyp.DataBind();
        ddlevtyp.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    //protected void cmdwntdate_Click(object sender, EventArgs e)
    //{
    //    calndrwntdate.Visible = true;
    //}
    //protected void cmdevdate_Click(object sender, EventArgs e)
    //{
    //    calndrevntdate.Visible = true;
    //}
    //protected void calndrwntdate_SelectionChanged(object sender, EventArgs e)
    //{
    //    txtwntdate.Text = calndrwntdate.SelectedDate.ToString();
    //    calndrwntdate.Visible = false;
    //}
    //protected void calndrevntdate_SelectionChanged(object sender, EventArgs e)
    //{
    //    txtevntdat.Text = calndrevntdate.SelectedDate.ToString();
    //    calndrevntdate.Visible = false;
    //}

    protected void ddlsamplcrd_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
    protected void ddlevtyp_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
    protected void ddlshpmnt_SelectedIndexChanged(object sender, EventArgs e)
    {
        calprice();
        txttotprice.Text = totalprice.ToString();
    }
}