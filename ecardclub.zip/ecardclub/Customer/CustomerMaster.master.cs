﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_CustomerMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void txtlgout_Click(object sender, EventArgs e)
    {
        Session["Customer"] = "";
        Session["Cid"] = "";
        Session["Cname"] = "";
        Session.Clear();
        Session.Abandon();
        Response.Redirect("~/Registration/login.aspx");

    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/Customer_req.aspx");
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/edit_cust_reg.aspx");
    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/edit_cust_req.aspx");
    }

    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/CustomerHome.aspx");
    }

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/View_Crdclb_brnch.aspx");
    }

    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/View_Offrs.aspx");
    }

    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/View_Shpmnt_mod.aspx");
    }

    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/Search_Crd_smpl.aspx");
    }

    protected void LinkButton9_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.Clear();
        Session["agencyid"] = null;
        Session["agencyname"] = null;
        Session["ag_hold_name"] = null;
        Response.Redirect("~/Registration/login.aspx");
    }
}
