﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_edit_cust_req : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcust();           
        }
    }
    //bind customer into gridview control.
    protected void bindcust()
    {
        obj.Query = string.Format(@"SELECT  Customer.Cname, Card_sample.Title, Shipment_mode.Shipmt_mode, Event_type.Ev_type, Customer_request.*
                         FROM   Customer_request INNER JOIN
                         Customer ON Customer_request.Cid = Customer.Cid INNER JOIN
                         Shipment_mode ON Customer_request.Shipmtid = Shipment_mode.Shipmtid INNER JOIN
                         Event_type ON Customer_request.Ev_typeid = Event_type.Ev_typeid INNER JOIN
                         Card_sample ON Customer_request.Sampleid = Card_sample.Sampleid WHERE Customer.Cid='" + Session["Cid"] + "'");
        obj.GetDataSet(obj.Query);
        dtcstreq.DataSource = obj.ds;
        dtcstreq.DataBind();
    }   
protected void  dtcstreq_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
{
    dtcstreq.PageIndex = e.NewPageIndex;
    bindcust();
}
protected void  dtcstreq_ModeChanging(object sender, DetailsViewModeEventArgs e)
{
    dtcstreq.ChangeMode(e.NewMode);
    bindcust();
}
protected void  dtcstreq_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
{
    try
    {
        //update the edited details to the table customer request.
        int Reqid = Convert.ToInt32(dtcstreq.DataKey.Value.ToString());
        DropDownList ddlcnm = (DropDownList)dtcstreq.FindControl("ddlcnm");
        DropDownList ddlcrdname = (DropDownList)dtcstreq.FindControl("ddlcrdname");
        TextBox txtnocpy = (TextBox)dtcstreq.FindControl("txtnocpy");
        TextBox txtwntdate = (TextBox)dtcstreq.FindControl("txtwntdate");
        TextBox txtreqdate = (TextBox)dtcstreq.FindControl("txtreqdate");
        TextBox txtsttus = (TextBox)dtcstreq.FindControl("txtsttus");
        DropDownList ddlshpmnt = (DropDownList)dtcstreq.FindControl("ddlshpmnt");
        TextBox txtshpadres = (TextBox)dtcstreq.FindControl("txtshpadres");
        DropDownList ddlevtyp = (DropDownList)dtcstreq.FindControl("ddlevtyp");
        TextBox txtbrdname = (TextBox)dtcstreq.FindControl("txtbrdname");
        TextBox txtgrmname = (TextBox)dtcstreq.FindControl("txtgrmname");
        TextBox txtadrs = (TextBox)dtcstreq.FindControl("txtadrs");
        TextBox txtcrdcnts = (TextBox)dtcstreq.FindControl("txtcrdcnts");
        TextBox txtevdat = (TextBox)dtcstreq.FindControl("txtevdat");
        TextBox txtevtym = (TextBox)dtcstreq.FindControl("txtevtym");
        TextBox txtvnue = (TextBox)dtcstreq.FindControl("txtvnue");
        obj.Query = "update Customer_request set Cid=" + ddlcnm.SelectedValue + ",Sampleid=" + ddlcrdname.SelectedValue + ",No_copy='" + txtnocpy.Text + "',Want_date='" + txtwntdate.Text + "',Req_date='" + txtreqdate.Text + "',Status='" + txtsttus.Text + "',Shipmtid=" + ddlshpmnt.SelectedValue + ",Shipmt_addr='" + txtshpadres.Text + "',Ev_typeid=" + ddlevtyp.SelectedValue + ",Bride_name='" + txtbrdname.Text + "',Groom_Name='" + txtgrmname.Text + "',Address='" + txtadrs.Text + "',Card_content='" + txtcrdcnts.Text + "',Ev_date='" + txtevdat.Text + "',Ev_time='" + txtevtym.Text + "',Venue='" + txtvnue.Text + "' where Reqid=" + Reqid + " ";
        dtcstreq.ChangeMode(DetailsViewMode.ReadOnly);
        obj.WriteData(obj.Query);
        Response.Write("<script>alert('Data Updated')</script>");
        bindcust();
    }
    catch (Exception ex)
    {
        lblmsg.Text = ex.ToString();
    }
}
protected void  dtcstreq_ItemDeleting(object sender, DetailsViewDeleteEventArgs e)
 {
    //delete the selected record from the table customer request.
    int Reqid = Convert.ToInt32(dtcstreq.DataKey.Value.ToString());
    obj.Query = "delete from Customer_request where Cid=" +Reqid .ToString() + " ";
    obj.WriteData(obj.Query);
    Response.Write("<script>alert('Data Deleted')</script>");
    bindcust();
 }
}