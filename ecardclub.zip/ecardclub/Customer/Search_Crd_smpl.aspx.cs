﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_Search_Crd_smpl : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            binddrpeventtype();
            binddrpformt();
            binddrpstyle();
            binddrpclr();
            binddrpptech();
            binddrpcrdsut();
            binddrptrmopt();
            binddrpsignatur();
            binddrpsiz();
            binddrppaprtyp();
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        obj.Query = "SELECT  Card_sample.* FROM  Card_sample INNER JOIN  Event_type ON Card_sample.Ev_typeid = Event_type.Ev_typeid INNER JOIN Format ON Card_sample.Formatid = Format.Formatid INNER JOIN Style ON Card_sample.Styleid = Style.Styleid INNER JOIN  Colour ON Card_sample.Colrid = Colour.Colrid INNER JOIN Print_Tech ON Card_sample.Print_techid = Print_Tech.Print_techid INNER JOIN Card_Suite ON Card_sample.Card_suid = Card_Suite.Card_suid INNER JOIN Envelop_trim_opt ON Card_sample.Trim_Optid = Envelop_trim_opt.Trim_Optid INNER JOIN Signature_collection ON Card_sample.Signid = Signature_collection.Signid INNER JOIN Size ON Card_sample.Sizeid = Size.Sizeid INNER JOIN Papertype ON Card_sample.Paper_Typeid = Papertype.Paper_Typeid";
        obj.GetDataSet(obj.Query);
        DataList1.DataSource = obj.ds;
        DataList1.DataBind();
        obj.ds.Clear();
    }


    public void binddrpeventtype()
    {
        obj.Query = "select * from Event_type";
        obj.GetDataSet(obj.Query);
        drpevntyp.DataSource = obj.ds;
        drpevntyp.DataTextField = "Ev_type";
        drpevntyp.DataValueField = "Ev_typeid";
        drpevntyp.DataBind();
        drpevntyp.Items.Insert(0, "");
    }
    public void binddrpformt()
    {
        obj.Query = "select * from Format";
        obj.SelectData(obj.Query);
        drpformt.DataSource = obj.dr;
        drpformt.DataTextField = "Formatname";
        drpformt.DataValueField = "Formatid";
        drpformt.DataBind();
        drpformt.Items.Insert(0, "--select format type--");
        obj.dr.Close();
    }
    public void binddrpstyle()
    {
        obj.Query = "select * from Style";
        obj.SelectData(obj.Query);
        drpstyle.DataSource = obj.dr;
        drpstyle.DataTextField = "Style";
        drpstyle.DataValueField = "Styleid";
        drpstyle.DataBind();
        drpstyle.Items.Insert(0, "--select style--");
        obj.dr.Close();
    }
    public void binddrpclr()
    {
        obj.Query = "select * from Colour";
        obj.SelectData(obj.Query);
        drpclr.DataSource = obj.dr;
        drpclr.DataTextField = "Color";
        drpclr.DataValueField = "Colrid";
        drpclr.DataBind();
        drpclr.Items.Insert(0, "--select colour--");
        obj.dr.Close();
    }
    public void binddrpptech()
    {
        obj.Query = "select * from Print_Tech";
        obj.SelectData(obj.Query);
        drpptech.DataSource = obj.dr;
        drpptech.DataTextField = "Tech";
        drpptech.DataValueField = "Print_techid";
        drpptech.DataBind();
        drpptech.Items.Insert(0, "--select printing technology--");
        obj.dr.Close();
    }
    public void binddrpcrdsut()
    {
        obj.Query = "select * from Card_Suite";
        obj.SelectData(obj.Query);
        drpcrdsut.DataSource = obj.dr;
        drpcrdsut.DataTextField = "Suite";
        drpcrdsut.DataValueField = "Card_suid";
        drpcrdsut.DataBind();
        drpcrdsut.Items.Insert(0, "--select card suite--");
        obj.dr.Close();
    }
    public void binddrptrmopt()
    {
        obj.Query = "select * from Envelop_trim_opt";
        obj.SelectData(obj.Query);
        drptrmoptn.DataSource = obj.dr;
        drptrmoptn.DataTextField = "Trim_Option";
        drptrmoptn.DataValueField = "Trim_Optid";
        drptrmoptn.DataBind();
        drptrmoptn.Items.Insert(0, "--select trim option--");
        obj.dr.Close();
    }
    public void binddrpsignatur()
    {
        obj.Query = "select * from Signature_collection";
        obj.SelectData(obj.Query);
        drpsignatur.DataSource = obj.dr;
        drpsignatur.DataTextField = "Signature";
        drpsignatur.DataValueField = "Signid";
        drpsignatur.DataBind();
        drpsignatur.Items.Insert(0, "--select signature--");
        obj.dr.Close();
    }
    public void binddrpsiz()
    {
        obj.Query = "select * from Size";
        obj.SelectData(obj.Query);
        drpsiz.DataSource = obj.dr;
        drpsiz.DataTextField = "Dimension";
        drpsiz.DataValueField = "Sizeid";
        drpsiz.DataBind();
        drpsiz.Items.Insert(0, "--select size--");
        obj.dr.Close();
    }
    public void binddrppaprtyp()
    {
        obj.Query = "select * from Papertype";
        obj.SelectData(obj.Query);
        drppaprtype.DataSource = obj.dr;
        drppaprtype.DataTextField = "Type";
        drppaprtype.DataValueField = "Paper_Typeid";
        drppaprtype.DataBind();
        drppaprtype.Items.Insert(0, "--select paper type--");
        obj.dr.Close();
    }
}