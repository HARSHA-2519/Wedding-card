﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_View_Offrs : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindofrs();
        }
    }
    //bind offers into gridview control.
    protected void bindofrs()
    {
        obj.Query = "select * from Offers ";
        obj.GetDataSet(obj.Query);
        dtofrs.DataSource = obj.ds;
        dtofrs.DataBind();
    }
    protected void dtofrs_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {
        dtofrs.PageIndex = e.NewPageIndex;
        bindofrs();
    }
}