﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_Payment : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindpaymnttype();
            bindrqst();
        }
    }  
     protected void cmdcancl_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Customer/Payment.aspx");
    }
     //clear all fields after submission.
    protected void clear()
    {
        txtamount.Text = "";
        txtcardno.Text = "";
    }
    protected void cmdsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            //insert a new record to the table payment type.first check whether that record is already exist or not.
            //if it exists a message will be displayed on the dialog box.otherwise  data will be added to the table.
            obj.Query = "select Pid from Payment where Reqid= "+ddlrqstid.SelectedValue+" and Amt='"+txtamount.Text+"' ";
            obj.SelectData(obj.Query);
            if (obj.dr.Read())
            {
                obj.dr.Close();
                Response.Write("<script>alert('already exist')</script>");
            }
            else
            {
                obj.dr.Close();
                obj.Query = "insert into Payment values(" + ddlpaymnttype.SelectedValue + ","+ddlrqstid.SelectedValue+",'" + txtamount.Text + "','" + System.DateTime.Now.ToString("MM/dd/yy") + "'," + txtcardno.Text + ")";
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('payment inserted')</script>");
            }
            clear();
        }
        catch (Exception ex)
        {
            lblmsg.Text= ex.ToString();
        }
    }
    //bind payment type into gridview control.
    protected void bindpaymnttype()
    {
        obj.Query = "select * from Payment_type";
        obj.SelectData(obj.Query);
        ddlpaymnttype.DataSource = obj.dr;
        ddlpaymnttype.DataTextField = "Pay_type";
        ddlpaymnttype.DataValueField = "Pay_typeid";
        ddlpaymnttype.DataBind();
        ddlpaymnttype.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
    protected void bindrqst()
    {
        obj.Query = "select * from Customer_request";
        obj.SelectData(obj.Query);
        ddlrqstid.DataSource = obj.dr;
        ddlrqstid.DataTextField = "Reqid";
        ddlrqstid.DataValueField = "Reqid";
        ddlrqstid.DataBind();
        ddlrqstid.Items.Insert(0, "--select--");
        obj.dr.Close();
    }
}