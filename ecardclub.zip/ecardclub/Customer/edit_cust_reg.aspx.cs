﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_edit_cust_reg : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            binddist();
        }
    }
    //bind district into details view control.
    protected void binddist()
    {
        obj.Query = "SELECT Customer.*, District.Dname FROM Customer INNER JOIN District ON Customer.Did = District.Did WHERE Cid='"+ Session["Cid"] + "'";
        obj.GetDataSet(obj.Query);
        dtcustreg.DataSource = obj.ds;
        dtcustreg.DataBind();       
    }    
        protected void dtcustreg_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {
            dtcustreg.PageIndex = e.NewPageIndex;
            binddist();
        }
        protected void dtcustreg_ModeChanging(object sender, DetailsViewModeEventArgs e)
        {
            dtcustreg.ChangeMode(e.NewMode);
            binddist();
        }
        protected void dtcustreg_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
        {
            try
            {
                //update the edited details to the table customer registration.
                int Cid = Convert.ToInt32(dtcustreg.DataKey.Value.ToString());
                TextBox txtcnm = (TextBox)dtcustreg.FindControl("txtcnm");
                TextBox txtadrs = (TextBox)dtcustreg.FindControl("txtadrs");
                DropDownList ddldid = (DropDownList)dtcustreg.FindControl("ddldid");
                TextBox txtemailid = (TextBox)dtcustreg.FindControl("txtemailid");
                TextBox txtphno = (TextBox)dtcustreg.FindControl("txtphno");
                TextBox txtusrnam = (TextBox)dtcustreg.FindControl("txtusrnam");
                TextBox txtpaswd = (TextBox)dtcustreg.FindControl("txtpaswd");
                TextBox txtregdat = (TextBox)dtcustreg.FindControl("txtregdat");
                TextBox txtstatus = (TextBox)dtcustreg.FindControl("txtstatus");
                obj.Query = "update Customer set Cname='" + txtcnm.Text + "',Caddress='" + txtadrs.Text + "',Did=" + ddldid.SelectedValue + ",EmailId='" + txtemailid.Text + "',Phone='" + txtphno.Text + "',Username='" + txtusrnam.Text + "',Password='" + txtpaswd.Text + "' where Cid=" + Cid + " ";
                dtcustreg.ChangeMode(DetailsViewMode.ReadOnly);
                obj.WriteData(obj.Query);
                Response.Write("<script>alert('Data Updated')</script>");
                binddist();
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.ToString();
            }
        }

}