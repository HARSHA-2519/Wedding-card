﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_View_Crdclb_brnch : System.Web.UI.Page
{
    ClsCard obj = new ClsCard();   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Customer"] == null)
        {
            Response.Redirect("~/Registration/Home.aspx");
        }
        else
        {
            obj.connect();
        }
        if (!IsPostBack)
        {
            bindcrdbrnch();
        }
    }
    //bind card branch into gridview control.
    protected void bindcrdbrnch()
    {
        obj.Query = "SELECT Card_club_branch.*, District.Dname FROM  Card_club_branch INNER JOIN District ON Card_club_branch.Did = District.Did";
        obj.SelectData(obj.Query);
        grdvwcrdbranch.DataSource = obj.dr;
        grdvwcrdbranch.DataBind();
        obj.dr.Close();
    }    
    protected void  grdvwcrdbranch_SelectedIndexChanged(object sender, EventArgs e)
    {  
        int id = Convert.ToInt32(grdvwcrdbranch.SelectedRow.Cells[0].Text);
        obj.Query = "SELECT Card_club_branch.*, District.Dname FROM  Card_club_branch INNER JOIN  District ON Card_club_branch.Did = District.Did where Clubid=" + id.ToString() + " ";
        obj.GetDataSet(obj.Query);
        dtcrdbrnch.DataSource = obj.ds;
        dtcrdbrnch.DataBind();
     }
}
